<?php
require('connection.php');
require('delete.php');
// require('status.php');
error_reporting(0);
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>To do list</title>
	<!-- Bootstrap Link -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link href="style.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
</head>
<body>
	<div class="container">
          <div class="row">
              <div class="col-lg-12">
               <div class="card">
                   <div class="card-header d-flex align-items-center justify-content-between">
                       <h3>My To Do List</h3>
                       <!-- Input form for Date Selection  start-->
                      	<form action="" method="POST">
                       		<input type="date" id="createat" name="createat">
                       		<button type="submit" class="btn btn-primary" name="submit">find</button>
                       	</form>
 				<!-- Input form for Date Selection End -->
 				<!-- List of header button  start-->
                       	<a href="todo.php" class="btn btn-info float-right">View all Todo</a>
                       <a href="index.php" class="btn btn-info float-right">Add a new Todo</a>
                       <a href="csvfile.php" class="btn btn-info float-right">Upload Csv</a>
                   </div>
                   <!-- List of header button  start-->

          <div class="card-body">
              
        <?php
        	// if the button pressed 
		if (isset($_POST['submit'])) {
			$sql = mysqli_query($db, "SELECT * FROM `todoitem`  where  createat='$_POST[createat]' ");
			if(mysqli_num_rows($sql) == 0) {
				echo "Sorry! No data found.";
			}
			 else {
				echo "<table class='table table-bordered table-hover' >";
				echo "<tr style='background-color: #6db6b9e6;'>";
				echo "<tr style=' color: #000; font-weight:bold; text-align:center;'>";
				//Table header
				echo "<th>"; echo "Todo List";  echo "</th>";
				echo "<th>"; echo "Todo Date";  echo "</th>";
				echo "<th>"; echo "Edit";  echo "</th>";
				echo "<th>"; echo "Delete";  echo "</th>";
				echo "<th>"; echo "Status";  echo "</th>";
				echo "</tr>";

				while ($row = mysqli_fetch_assoc($sql)) {
					echo "<tr>";
					echo "<tr style=' color:#000; font-weight:bold; text-align:center;'>";
					$id=$row['id'];
				    echo "<td >"; echo $row['item_todo']; echo "</td>";
				    echo "<td>"; echo $row['createat']; echo "</td>";
				    echo "<td>"; echo "<a href='edit.php?id=$id ' class='btn btn-success'>"; echo "Edit";  echo "</td>";
				    echo "<td>"; echo "<a href='delete.php?id=$id ' class='btn btn-danger remove' >"; echo "Delete"; echo "</td>";

				    if($row['status']== '0') {             
                        echo "<td>"; echo "<a href=status.php?id=".$row['id']." class='btn btn-warning'>Not Done</a>"; echo "</td>";}
                    else {
                        echo "<td>"; echo"<a href=status.php?id=".$row['id']." class='btn btn-success'>Done</a>";  echo "</td>";
                    }
					echo "</tr>";
				}
				echo "</table>";
			}
		}

		/*if button is not pressed.*/ 
		else {
			$res = mysqli_query($db, "SELECT * FROM `todoitem` ORDER BY `todoitem`.`createat` ");

			echo "<table class='table table-bordered table-hover' >";
			echo "<tr style='background-color: #6db6b9e6;'>";
			echo "<tr style=' color: #000; font-weight:bold; text-align:center;'>";
			//Table header
				
				echo "<th>"; echo "Todo List";  echo "</th>";
				echo "<th>"; echo "Todo Date";  echo "</th>";
				echo "<th>"; echo "Edit";  echo "</th>";
				echo "<th>"; echo "Delete";  echo "</th>";
				echo "<th>"; echo "Status";  echo "</th>";
				echo "</tr>";
			echo "</tr>";

			while ($row = mysqli_fetch_assoc($res)) {
				echo "<tr>";
				echo "<tr style=' color:#000; font-weight:bold; text-align:center;'>";
					$id=$row['id'];
				    echo "<td >"; echo $row['item_todo']; echo "</td>";
				    echo "<td>"; echo $row['createat']; echo "</td>";
				    echo "<td>"; echo "<a href='edit.php?id=$id ' class='btn btn-success'>"; echo "Edit";  echo "</td>";
				    echo "<td>"; echo "<a href='delete.php?id=$id ' class='btn btn-danger remove' >"; echo "Delete"; echo "</td>";
				     	


				    if($row['status']== '0') {
              
                        echo "<td>"; echo "<a href=status.php?id=".$row['id']." class='btn btn-warning'>Not Done</a>"; echo "</td>";}
                    else {
                        echo "<td>"; echo"<a href=status.php?id=".$row['id']." class='btn btn-success'>Done</a>";  echo "</td>";
                    }
				  
			

				echo "</tr>";
			}
			echo "</table>";
		}

		?>
		<p class="text-center"> copyright &#169 2023  Ritesh kumar</p>
		   </div>
         </div>
       </div>
     </div>
  </div>
</body>
</html>