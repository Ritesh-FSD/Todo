<?php
require 'connection.php';
header("Access-Control-Allow-Origin: *");
function console_log($output, $with_script_tags = true) {
    $js_code = 'console.log(' . json_encode($output, JSON_HEX_TAG) . 
');';
    if ($with_script_tags) {
        $js_code = '<script>' . $js_code . '</script>';
    }
    echo $js_code;
}


// If button is pressed
if(isset($_POST['submit'])){
    $filename=$_FILES['file']["tmp_name"];

    if($_FILES['file']["size"]>0){
        $file=fopen($filename,"r");
        


        while (($sql = fgetcsv($file,10000,",")) !==FALSE) {
        $result ="INSERT INTO `todoitem` (id,item_todo,createat,status) VALUES('".$sql[0]."' , '".$sql[1]."', '".$sql[2]."', '".$sql[3]."')";
console_log($result);
                $import = mysqli_query($db,$result);
                console_log($import);
               
        }
        console_log($import);
         if(!empty($import)){
                    echo "csv data imported successfully"; 
                }
                else{
                    echo "Not imported";
                }
    }
}

?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>To do app</title>
    <!-- Bootstrap Link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" >
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
</head>
<body>

<!--  Input Form for Select CSV FILE -->
<div class="container" style="padding-top:50px;">
  <div class="row justify-content-center">
    <div class="col-lg-4 mt-auto border border-danger">
        <div class="header">
            <p class="heading text-center" style="font-size:16px; font-weight: 700;" > My todo List </p>
        </div>
        <form action="" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">select CSV file</label>
         <input type="file" class="form-control" id="exampleFormControlInput1" name="file" accept=".csv">
        </div>
        <button type="submit" name="submit" class="btn btn-primary mb-3">Upload</button>
         <a href="todo.php" class="btn btn-warning " style="float:right;"> View Todo </a>
    </div>
    <p class="text-center"> copyright &#169 2023  Ritesh kumar</p>
    </form>
  </div>
</div>
</body>
</html>