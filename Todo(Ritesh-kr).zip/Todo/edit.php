
	<?php
	require ('connection.php');
	error_reporting(0);

    $id = $_GET['id'];

	//selecting data associated with this particular id
	$result = mysqli_query($db, "SELECT * FROM `todoitem`  WHERE id=$id");

	while($row = mysqli_fetch_array($result))
	{
		$id = $row['id'];
		$item_todo = $row['item_todo'];
		$createat = $row['createat'];
	}


	?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>To do app</title>
	<!-- Bootstrap Link -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link href="style.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
</head>
<body>

<div class="container pd-10 mt-50">
  <div class="row justify-content-center">
    <div class="col-lg-4 mt-auto border border-danger">
    	<div class="header">
    		<p class="heading text-center font-900" > My todo List </p>
    	</div>
    	<div class="mb-3">
    		<form action="editprocess.php" method="post">
    			<input type="hidden" name="id" value=<?php echo $_GET['id'];?> >
  			<label for="exampleFormControlInput1" class="form-label text-dark">My Todo</label>
  			<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter a Todo" name="item_todo"  value="<?php echo $item_todo;?>"  >
		</div>
		<div class="mb-3">
		  <label for="exampleFormControlTextarea1" class="form-label"> Todo Date </label>
		 <input type="Date" class="form-control" id="exampleFormControlInput1" name="createat"   value="<?php echo $createat;?>"  >
		</div>
 		<button type="submit" name="update" class="btn btn-primary mb-3">Add Task</button>
    </div>
	</form>
	<p class="text-center"> copyright &#169 2023  Ritesh kumar</p>
  </div>
</div>
</body>
</html>