
<?php 
	require 'connection.php';
	error_reporting(0);
  
	// if submit button clicked
	if (isset($_POST['submit'])) {

			$sql = "INSERT INTO `todoitem`  VALUES ('', '$_POST[item_todo]', '$_POST[createat]','')";
			$result= mysqli_query($db, $sql);
			 if ($result) {
			    echo '<script language="javascript">';
        echo 'alert("Data added Successfully "); location.href="todo.php"';
        echo '</script>';
			  }else{
    				echo '<script language="javascript">';
        echo 'alert(" Data Not added Successfully "); location.href="index.php"';
        echo '</script>';
					}
		}	

	?>
	 
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>To do app</title>
	<!-- Bootstrap Link -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" >
	<link href="style.css" rel="stylesheet">

	
</head>
<body>

 <div class="container pd-10 mt-50">
  <div class="row justify-content-center">
    <div class="col-lg-4 mt-auto border border-danger">
    	<div class="header">
    		<p class="heading text-center font-900" > My todo List </p>
    	</div>
    	<div class="mb-3">
    		<!-- created Todo Form -->
    		<form action="" method="POST">
  			<label for="exampleFormControlInput1" class="form-label text-dark">My Todo</label>
  			<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter a Item" name="item_todo" required>
		</div>
		<div class="mb-3">
		  <label for="exampleFormControlTextarea1" class="form-label">Date</label>
		 <input type="Date" class="form-control" id="exampleFormControlInput1" name="createat" required>
		</div>
 		<button type="submit" name="submit" class="btn btn-primary mb-3">Add Task</button>
 		 <a href="todo.php" class="btn btn-warning seelist"> View Todo </a>
    </div>
    <p class="text-center"> copyright &#169 2023  Ritesh kumar</p>
	</form>
	<!-- End Form -->
  </div>
</div>
<!-- Bootstrap Javascript  -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
</body>
</html>