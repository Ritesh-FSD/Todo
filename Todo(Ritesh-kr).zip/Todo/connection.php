<?php 
	// connect to database
	$db = mysqli_connect("localhost", "root", "", "todo");

	// host-server,username,password,database - name
	
	?>