Requirement
1.Xampp
2.4Gb Ram
3.chrome,Microsoft edge
4. windows 7,8,10,11

Step to Run 
1.First create a database on phpmyadmin of todo.
2.select the todo.sql from db file and import it into todo database.
3.Run index.php.
