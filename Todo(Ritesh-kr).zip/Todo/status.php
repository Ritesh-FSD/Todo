<?php
  
    require 'connection.php';
  
    if (isset($_GET['id'])){
  		
        $row=$_GET['id'];
  
   
        $sql="UPDATE `todoitem` SET  `status`=1 WHERE id='$row'";
  
        // Execute the query
        mysqli_query($db,$sql);
    }

  
    header('location: todo.php');
?>

?>