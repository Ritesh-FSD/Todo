
 <?php
require ('connection.php');
error_reporting(0);
// if update button is pressed 
if(isset($_POST['update']))
{	

$id = mysqli_real_escape_string($db, $_POST['id']);
$item_todo = mysqli_real_escape_string($db, $_POST['item_todo']);
$createat = mysqli_real_escape_string($db, $_POST['createat']);	

	
$result = mysqli_query($db, "UPDATE `todoitem` SET item_todo='$item_todo',createat='$createat' WHERE id=$id");
			 if ($result) {
			    echo '<script language="javascript">';
        echo 'alert("Data Edited Successfully "); location.href="todo.php"';
        echo '</script>';
			  }else{
    				echo '<script language="javascript">';
        echo 'alert(" Data Not Edited Successfully "); location.href="edit.php"';
        echo '</script>';
					}

}

?>