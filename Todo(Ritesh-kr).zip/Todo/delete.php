<?php
require('connection.php');
error_reporting(0);

$id=$_GET['id'];


$query = "DELETE FROM `todoitem` WHERE id=$id ";
    $delete_query = mysqli_query($db, $query);

    if($delete_query){
                echo '<script language="javascript">';
        echo 'alert(" Are you sure want to Delete? "); location.href="todo.php"';
        echo '</script>';
              }
        
?>



